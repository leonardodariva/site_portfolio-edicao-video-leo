"use client";

import { useState } from "react";
import { navigationLinks } from "@/data/navigation";

export function MobileMenu() {
  const [open, setOpen] = useState(false);

  return (
    <div className="mobile-menu-wrap">
      <button
        className="menu-button"
        type="button"
        aria-expanded={open}
        aria-controls="mobile-navigation"
        aria-label={open ? "Fechar menu" : "Abrir menu"}
        onClick={() => setOpen((value) => !value)}
      >
        <span />
        <span />
        <span />
      </button>
      {open && (
        <div className="menu-overlay">
          <nav id="mobile-navigation" className="mobile-navigation" aria-label="Navegação principal">
            <p>Navegação</p>
            {navigationLinks.map(([label, href], index) => (
              <a key={href} href={href} onClick={() => setOpen(false)}>
                <small>0{index + 1}</small>
                <span>{label}</span>
                <i aria-hidden="true">↗</i>
              </a>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}
