"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

type TrailPoint = { x: number; y: number };

export function CursorExperience() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  useEffect(() => {
    const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!finePointer.matches || reducedMotion.matches) return;

    const cursor = cursorRef.current;
    if (!cursor) return;

    let targetX = window.innerWidth / 2;
    let targetY = window.innerHeight / 2;
    let currentX = targetX;
    let currentY = targetY;
    let cursorFrame = 0;

    const moveCursor = (event: MouseEvent) => {
      targetX = event.clientX;
      targetY = event.clientY;
      cursor.classList.add("is-visible");
    };

    const updateCursorState = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const overProject = Boolean(target.closest(".project-image-link"));
      const overControl = Boolean(target.closest("a, button, [role='button']"));
      cursor.classList.toggle("is-explore", overProject);
      cursor.classList.toggle("is-big", !overProject && overControl);
    };

    const hideCursor = (event: MouseEvent) => {
      if (!event.relatedTarget) cursor.classList.remove("is-visible");
    };

    const pressCursor = () => cursor.classList.add("is-pressed");
    const releaseCursor = () => cursor.classList.remove("is-pressed");

    const followCursor = () => {
      currentX += (targetX - currentX) * 0.22;
      currentY += (targetY - currentY) * 0.22;
      cursor.style.transform = `translate3d(${currentX.toFixed(1)}px, ${currentY.toFixed(1)}px, 0) translate(-50%, -50%)`;
      cursorFrame = window.requestAnimationFrame(followCursor);
    };

    window.addEventListener("mousemove", moveCursor, { passive: true });
    window.addEventListener("mouseover", updateCursorState, { passive: true });
    window.addEventListener("mouseout", hideCursor, { passive: true });
    window.addEventListener("mousedown", pressCursor, { passive: true });
    window.addEventListener("mouseup", releaseCursor, { passive: true });
    followCursor();

    const hero = document.querySelector<HTMLElement>(".hero");
    let fieldFrame = 0;
    let resizeObserver: ResizeObserver | undefined;
    let canvas: HTMLCanvasElement | undefined;
    let removeFieldListeners: (() => void) | undefined;

    if (hero) {
      canvas = document.createElement("canvas");
      canvas.className = "cursor-field";
      canvas.setAttribute("aria-hidden", "true");
      hero.prepend(canvas);
      hero.classList.add("has-cursor-field");

      const context = canvas.getContext("2d");
      if (context) {
        const ratio = Math.min(window.devicePixelRatio || 1, 2);
        const trail: TrailPoint[] = [];
        const trailLength = 42;
        const gap = 16;
        let width = 1;
        let height = 1;
        let mouseX = -9999;
        let mouseY = -9999;
        let easedX = -9999;
        let easedY = -9999;
        let clientX = -9999;
        let clientY = -9999;
        let inside = false;

        const sizeCanvas = () => {
          const rect = hero.getBoundingClientRect();
          width = Math.max(1, rect.width);
          height = Math.max(1, rect.height);
          canvas!.width = Math.round(width * ratio);
          canvas!.height = Math.round(height * ratio);
          context.setTransform(ratio, 0, 0, ratio, 0, 0);
        };

        const locatePointer = (event: MouseEvent) => {
          clientX = event.clientX;
          clientY = event.clientY;
          const rect = hero.getBoundingClientRect();
          inside = clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom;
          if (!inside) {
            mouseX = -9999;
            mouseY = -9999;
            return;
          }
          mouseX = clientX - rect.left;
          mouseY = clientY - rect.top;
          if (easedX < -1000) {
            easedX = mouseX;
            easedY = mouseY;
          }
        };

        const relocateOnScroll = () => {
          if (!inside || clientX < -1000) return;
          const rect = hero.getBoundingClientRect();
          mouseX = clientX - rect.left;
          mouseY = clientY - rect.top;
        };

        const drawField = () => {
          easedX += (mouseX - easedX) * 0.1;
          easedY += (mouseY - easedY) * 0.1;
          if (inside) trail.push({ x: easedX, y: easedY });
          while (trail.length > trailLength) trail.shift();
          if (!inside && trail.length) trail.shift();

          context.clearRect(0, 0, width, height);

          trail.forEach((point, index) => {
            const strength = (index + 1) / trail.length;
            const radius = 28 + strength * 86;
            const alpha = 0.028 * strength * strength;
            const gradient = context.createRadialGradient(point.x, point.y, 0, point.x, point.y, radius);
            gradient.addColorStop(0, `rgba(55,123,255,${(alpha * 5).toFixed(4)})`);
            gradient.addColorStop(0.46, `rgba(55,123,255,${(alpha * 1.8).toFixed(4)})`);
            gradient.addColorStop(1, "rgba(55,123,255,0)");
            context.fillStyle = gradient;
            context.beginPath();
            context.arc(point.x, point.y, radius, 0, Math.PI * 2);
            context.fill();
          });

          const head = trail.at(-1) ?? { x: -9999, y: -9999 };
          for (let y = gap / 2; y < height; y += gap) {
            for (let x = gap / 2; x < width; x += gap) {
              const deltaX = x - head.x;
              const deltaY = y - head.y;
              const distance = Math.hypot(deltaX, deltaY);
              let offsetX = 0;
              let offsetY = 0;
              let opacity = 0.12;
              let radius = 0.9;

              if (distance < 145) {
                const force = (1 - distance / 145) ** 2;
                const safeDistance = Math.max(distance, 1);
                offsetX = (deltaX / safeDistance) * force * 12;
                offsetY = (deltaY / safeDistance) * force * 12;
                opacity += force * 0.2;
                radius += force * 0.65;
              }

              context.beginPath();
              context.arc(x + offsetX, y + offsetY, radius, 0, Math.PI * 2);
              context.fillStyle = `rgba(151,166,255,${opacity.toFixed(3)})`;
              context.fill();
            }
          }

          fieldFrame = window.requestAnimationFrame(drawField);
        };

        sizeCanvas();
        resizeObserver = new ResizeObserver(sizeCanvas);
        resizeObserver.observe(hero);
        window.addEventListener("mousemove", locatePointer, { passive: true });
        window.addEventListener("scroll", relocateOnScroll, { passive: true });
        drawField();

        removeFieldListeners = () => {
          window.removeEventListener("mousemove", locatePointer);
          window.removeEventListener("scroll", relocateOnScroll);
        };
      }
    }

    return () => {
      window.cancelAnimationFrame(cursorFrame);
      window.cancelAnimationFrame(fieldFrame);
      window.removeEventListener("mousemove", moveCursor);
      window.removeEventListener("mouseover", updateCursorState);
      window.removeEventListener("mouseout", hideCursor);
      window.removeEventListener("mousedown", pressCursor);
      window.removeEventListener("mouseup", releaseCursor);
      removeFieldListeners?.();
      resizeObserver?.disconnect();
      canvas?.remove();
      hero?.classList.remove("has-cursor-field");
    };
  }, [pathname]);

  return (
    <div ref={cursorRef} className="custom-cursor" aria-hidden="true">
      <span>Explorar</span>
    </div>
  );
}
