import Link from "next/link";
import type { Project } from "@/data/site";

export function ProjectCard({ project, index }: { project: Project; index: number }) {
  return (
    <article className={`project-card project-card-${index + 1}`} data-reveal>
      <Link className="project-image-link" href={`/projetos/${project.slug}`} aria-label={`Ver case ${project.title}`}>
        <span className="project-image-frame">
          <img src={project.coverImage} alt={`Interface do projeto ${project.title}`} loading={index === 0 ? "eager" : "lazy"} />
          <span className="project-image-wash" aria-hidden="true" />
        </span>
      </Link>
      <div className="project-card-copy">
        <h3><Link href={`/projetos/${project.slug}`}>{project.title}</Link></h3>
        <p>{project.summary}</p>
        <div className="project-card-meta">
          <span>0{index + 1}</span>
          <span>{project.eyebrow}</span>
          <Link href={`/projetos/${project.slug}`}>Ver projeto ↗</Link>
        </div>
      </div>
    </article>
  );
}
