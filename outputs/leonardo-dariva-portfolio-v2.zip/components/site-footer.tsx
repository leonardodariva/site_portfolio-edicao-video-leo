import Link from "next/link";
import { siteConfig } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="page-shell">
        <div className="footer-brand-row">
          <Link className="monogram footer-monogram" href="/" aria-label="Leonardo Dariva — início"><span>LD</span></Link>
          <span>Front-end Developer · Brasil</span>
        </div>
        <div className="footer-heading">
          <h2>Vamos construir<br />o próximo projeto.</h2>
          <a className="round-cta" href={siteConfig.linkedin} target="_blank" rel="noreferrer">Conversar <span>↗</span></a>
        </div>
        <div className="footer-grid">
          <div><span className="footer-label">Disponível para</span><p>Front-end · React · Product Engineering · Game UI</p></div>
          <div className="footer-links"><span className="footer-label">Links</span><a href={siteConfig.linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a><a href={siteConfig.github} target="_blank" rel="noreferrer">GitHub ↗</a><Link href="/curriculo">Currículo ↗</Link></div>
          <div><span className="footer-label">Baseado em</span><p>Apucarana, Paraná<br />Brasil</p></div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Leonardo Dariva</span>
          <span>Desenvolvido com Next.js</span>
          <a href="#top">↑ Voltar ao topo</a>
        </div>
      </div>
    </footer>
  );
}
