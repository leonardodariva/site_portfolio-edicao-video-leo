import type { Project } from "@/data/site";

export function ProjectVisual({ type }: { type: Project["visual"] }) {
  if (type === "dance") {
    return (
      <div className="project-visual dance-visual" aria-hidden="true">
        <div className="dance-nav"><span>NO RITMO</span><span>MENU</span></div>
        <div className="dance-copy">
          <small>DESDE 1995</small>
          <strong>O seu ritmo.<br />A sua dança.</strong>
          <span className="dance-cta">CONHEÇA AS AULAS ↗</span>
        </div>
        <div className="dance-orbit dance-orbit-one" />
        <div className="dance-orbit dance-orbit-two" />
        <div className="dance-figure"><span /><i /></div>
      </div>
    );
  }

  return (
    <div className="project-visual pirate-visual" aria-hidden="true">
      <div className="game-topbar">
        <span>PIRATE BATTLE</span>
        <span>02:00</span>
        <span>000240</span>
      </div>
      <div className="island island-one" />
      <div className="island island-two" />
      <div className="ship player-ship"><span>▲</span></div>
      <div className="ship enemy-ship"><span>▲</span></div>
      <div className="projectile projectile-one" />
      <div className="projectile projectile-two" />
      <div className="game-status"><span>HULL 84%</span><span>W A S D · Q E · SPACE</span></div>
    </div>
  );
}
