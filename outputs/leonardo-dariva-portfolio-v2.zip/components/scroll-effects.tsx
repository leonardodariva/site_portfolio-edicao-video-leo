"use client";

import { useEffect } from "react";

export function ScrollEffects() {
  useEffect(() => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const revealItems = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));

    if (reducedMotion.matches) {
      revealItems.forEach((item) => item.classList.add("is-visible"));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add("is-visible");
      }),
      { threshold: 0.12, rootMargin: "0px 0px -8% 0px" },
    );
    revealItems.forEach((item) => observer.observe(item));

    const footer = document.querySelector<HTMLElement>(".site-footer");
    const lightFooter = (event: PointerEvent) => {
      if (!footer) return;
      const rect = footer.getBoundingClientRect();
      footer.style.setProperty("--footer-x", `${event.clientX - rect.left}px`);
      footer.style.setProperty("--footer-y", `${event.clientY - rect.top}px`);
    };

    footer?.addEventListener("pointermove", lightFooter, { passive: true });

    return () => {
      observer.disconnect();
      footer?.removeEventListener("pointermove", lightFooter);
    };
  }, []);

  return null;
}
