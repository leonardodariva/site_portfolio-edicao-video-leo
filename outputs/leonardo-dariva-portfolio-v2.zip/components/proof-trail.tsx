"use client";

import Link from "next/link";
import { useEffect, useRef } from "react";

type TrailItem = { src: string; href: string; alt: string };

export function ProofTrail({ items }: { items: TrailItem[] }) {
  const stageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stage = stageRef.current;
    const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!stage || !finePointer.matches || reducedMotion.matches) return;

    let lastX = -100;
    let lastY = -100;
    let itemIndex = 0;
    let zIndex = 1;

    const addThumbnail = (event: PointerEvent) => {
      const rect = stage.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      if (Math.hypot(x - lastX, y - lastY) < 58) return;
      lastX = x;
      lastY = y;

      const item = items[itemIndex % items.length];
      itemIndex += 1;
      const anchor = document.createElement("a");
      const image = document.createElement("img");
      anchor.href = item.href;
      anchor.className = "trail-thumb";
      anchor.setAttribute("aria-label", item.alt);
      anchor.style.left = `${x}px`;
      anchor.style.top = `${y}px`;
      anchor.style.zIndex = `${zIndex++}`;
      image.src = item.src;
      image.alt = "";
      anchor.append(image);
      stage.append(anchor);
      window.setTimeout(() => anchor.classList.add("is-settled"), 20);
      window.setTimeout(() => anchor.remove(), 1650);
    };

    stage.addEventListener("pointermove", addThumbnail, { passive: true });
    return () => stage.removeEventListener("pointermove", addThumbnail);
  }, [items]);

  return (
    <div ref={stageRef} className="proof-trail-stage">
      <div className="proof-trail-copy" data-reveal>
        <p className="section-label">Veja por você mesmo</p>
        <h2>O trabalho<br />aparece no<br />movimento.</h2>
        <p>Mova o cursor por esta área para percorrer telas reais dos projetos.</p>
        <Link href="/projetos/pirate-battle">Abrir o primeiro case <span>↗</span></Link>
      </div>
      <div className="proof-static-mobile" aria-hidden="true">
        {items.slice(0, 3).map((item, index) => <img key={`${item.src}-${index}`} src={item.src} alt="" loading="lazy" />)}
      </div>
    </div>
  );
}
