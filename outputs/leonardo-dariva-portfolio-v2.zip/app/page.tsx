import Link from "next/link";
import { HeroTitle } from "@/components/hero-title";
import { IntroLoader } from "@/components/intro-loader";
import { ProjectCard } from "@/components/project-card";
import { ProofTrail } from "@/components/proof-trail";
import { ScrollEffects } from "@/components/scroll-effects";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { experience, projects, siteConfig, technologyGroups } from "@/data/site";

const trailItems = projects.flatMap((project) =>
  [project.coverImage, ...project.gallery].map((src) => ({
    src,
    href: `/projetos/${project.slug}`,
    alt: `Abrir o case ${project.title}`,
  })),
);

const journey = [
  { number: "01", title: "Entender o contexto", text: "Objetivos, pessoas e restrições entram primeiro. A tecnologia vem depois, como consequência de uma decisão clara.", mark: "◎" },
  { number: "02", title: "Desenhar o sistema", text: "Fluxos, conteúdo, estados e componentes formam uma linguagem única antes que a interface ganhe código.", mark: "◇" },
  { number: "03", title: "Construir com intenção", text: "React, TypeScript e uma arquitetura preparada para crescer sem perder legibilidade, acesso ou desempenho.", mark: "</>" },
  { number: "04", title: "Validar e evoluir", text: "Testes, responsividade e observação do uso real transformam a primeira entrega em um produto que continua melhorando.", mark: "✓" },
];

export default function Home() {
  return (
    <>
      <IntroLoader />
      <ScrollEffects />
      <SiteHeader />

      <main id="top">
        <section className="hero v3-hero" aria-labelledby="hero-title">
          <div className="page-shell v3-hero-inner">
            <div className="hero-kicker">
              <span>Leonardo Dariva</span>
              <span>Portfólio / 2026</span>
              <span>Brasil · disponível para colaborar</span>
            </div>
            <div className="v3-hero-copy" id="hero-title"><HeroTitle /></div>
            <div className="hero-bottomline">
              <p>Transformo contexto de produto em interfaces claras, acessíveis e prontas para crescer.</p>
              <div className="hero-scroll-cue"><span /> Role para explorar</div>
              <p>React · TypeScript · Next.js · UI/UX</p>
            </div>
          </div>
        </section>

        <section id="processo" className="journey-section">
          <div className="page-shell journey-layout">
            <div className="journey-intro" data-reveal>
              <p className="section-label">Como eu trabalho</p>
              <h2>Um parceiro de desenvolvimento<br />em quem você pode confiar.</h2>
              <p>Entro onde a execução importa — da descoberta e da interface até a construção e o lançamento. Assim um projeto avança da primeira conversa para o produto no ar.</p>
            </div>
            <div className="journey-cards">
              {journey.map((item) => (
                <article className="journey-card" key={item.number}>
                  <div className="journey-number">{item.number}</div>
                  <div className="journey-mark" aria-hidden="true">{item.mark}</div>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="projetos" className="section v3-projects-section">
          <div className="page-shell">
            <div className="v3-section-heading" data-reveal>
              <p className="section-label">Trabalho selecionado</p>
              <h2>Projetos recentes.</h2>
            </div>
            <div className="work-grid">
              {projects.map((project, index) => <ProjectCard key={project.slug} project={project} index={index} />)}
            </div>
          </div>
        </section>

        <section id="sobre" className="section v3-about-section">
          <div className="page-shell v3-about-grid">
            <div className="v3-about-portrait" data-reveal>
              <div className="portrait-window">
                <img src="https://avatars.githubusercontent.com/u/48518784?v=4" alt="Retrato de Leonardo Dariva" loading="lazy" />
              </div>
              <div className="portrait-caption"><span>Leonardo Dariva — Front-end Developer</span><span>Apucarana · PR</span></div>
            </div>
            <div className="v3-about-copy" data-reveal>
              <p className="section-label">Sobre mim</p>
              <h2>Existe uma pessoa<br />por trás do código.</h2>
              <p className="about-statement">Sou Leonardo, desenvolvedor front-end com experiência anterior em UI/UX e Product Design.</p>
              <p>Essa trajetória me ensinou a enxergar o produto inteiro: problema, experiência, interface e implementação. Hoje aprofundo React, TypeScript, Next.js, APIs, arquitetura e testes, evoluindo progressivamente para Full Stack.</p>
              <div className="experience-intro">
                <p className="section-label">Experiência</p>
                <p>Trabalho melhor em equipes que valorizam clareza, colaboração e interfaces bem executadas, conectando produto e engenharia.</p>
              </div>
              <div className="career-list">
                {experience.map((item) => (
                  <article key={item.company}><h3>{item.company}</h3><p>{item.role}</p><small>{item.period}</small></article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="stack" className="section v3-stack-section">
          <div className="page-shell">
            <div className="v3-stack-title" data-reveal><p className="section-label">Tecnologias</p><h2>Ferramentas entram<br />quando fazem sentido.</h2></div>
            <div className="capability-list">
              {technologyGroups.map((group, index) => (
                <article key={group.title} data-reveal><span>0{index + 1}</span><div><h3>{group.title}</h3><p>{group.description}</p></div><ul>{group.items.map((item) => <li key={item}>{item}</li>)}</ul></article>
              ))}
            </div>
          </div>
        </section>

        <section id="prova" className="v3-proof-section">
          <ProofTrail items={trailItems} />
          <div className="proof-manifesto">
            <div className="proof-manifesto-top"><span>Engenharia + produto</span><span>02 projetos completos</span></div>
            <blockquote data-reveal>“Código não termina na tela. Ele precisa sustentar o uso, explicar suas decisões e continuar legível quando o produto mudar.”</blockquote>
            <div className="proof-numbers">
              <article><strong>69</strong><span>testes unitários</span></article>
              <article><strong>22</strong><span>cenários E2E</span></article>
              <article><strong>60</strong><span>updates / segundo</span></article>
            </div>
          </div>
        </section>

        <section id="experiencia" className="section delivery-section">
          <div className="page-shell">
            <div className="delivery-heading" data-reveal>
              <div><p className="section-label">Continue explorando</p><h2>Mais perto<br />do trabalho.</h2></div>
              <p>Abra os cases, experimente o produto publicado ou examine as decisões no código-fonte.</p>
            </div>
            <div className="delivery-list">
              <Link href="/projetos/pirate-battle"><span>01</span><strong>Case Pirate Battle</strong><small>Produto completo</small><i>↗</i></Link>
              <a href={projects[0].liveUrl} target="_blank" rel="noreferrer"><span>02</span><strong>Jogar agora</strong><small>Deploy público</small><i>↗</i></a>
              <a href={siteConfig.github} target="_blank" rel="noreferrer"><span>03</span><strong>GitHub</strong><small>Código e projetos</small><i>↗</i></a>
              <Link href="/curriculo"><span>04</span><strong>Currículo</strong><small>Trajetória profissional</small><i>↗</i></Link>
            </div>
          </div>
        </section>
      </main>
      <div id="contato"><SiteFooter /></div>
    </>
  );
}
