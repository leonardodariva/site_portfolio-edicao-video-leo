const deploymentUrl =
  process.env.NEXT_PUBLIC_SITE_URL ??
  (process.env.VERCEL_PROJECT_PRODUCTION_URL
    ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
    : "http://localhost:3000");

export const siteConfig = {
  name: "Leonardo Dariva",
  role: "Front-end Developer",
  description:
    "Desenvolvedor front-end com background em UI/UX, construindo interfaces acessíveis, responsivas e orientadas a produto.",
  url: deploymentUrl,
  github: "https://github.com/leonardodariva",
  linkedin: "https://www.linkedin.com/in/leonardodariva",
  email: "",
};

export type Project = {
  slug: string;
  title: string;
  eyebrow: string;
  year: string;
  summary: string;
  objective: string;
  contribution: string;
  challenge: string;
  stack: string[];
  features: string[];
  metrics?: { value: string; label: string }[];
  liveUrl?: string;
  repositoryUrl: string;
  visual: "pirate" | "dance";
  coverImage: string;
  gallery: string[];
  featured: boolean;
};

export const projects: Project[] = [
  {
    slug: "pirate-battle",
    title: "Pirate Battle",
    eyebrow: "Jungle Gaming · Technical Challenge",
    year: "2026",
    summary:
      "Um shooter naval 2D para navegador, com simulação em tempo real, controles por teclado e toque, inimigos com comportamentos distintos e uma camada de dados resiliente.",
    objective:
      "Transformar um desafio técnico em uma experiência de jogo completa, testável e pronta para produção — sem esconder a complexidade da simulação dentro da interface.",
    contribution:
      "Desenvolvi o produto de ponta a ponta: arquitetura, regras da simulação, renderização, interface, API mockada, persistência, acessibilidade e estratégia de testes.",
    challenge:
      "Separar o loop de jogo da renderização e da UI. A simulação roda em TypeScript puro com timestep fixo; PixiJS desenha snapshots e React recebe apenas um resumo semântico desacelerado.",
    stack: [
      "React 19",
      "TypeScript",
      "PixiJS 8",
      "Vite",
      "Vitest",
      "Playwright",
      "TanStack Query",
      "Axios",
      "MSW",
    ],
    features: [
      "Combate naval com três tipos de disparo",
      "Inimigos Chaser e Shooter",
      "Controles desktop e mobile",
      "Ranking e histórico de partidas",
      "Fila offline e registro idempotente",
      "Estados, colisões e persistência",
    ],
    metrics: [
      { value: "69", label: "testes unitários" },
      { value: "22", label: "cenários E2E" },
      { value: "60", label: "updates por segundo" },
      { value: "strict", label: "TypeScript" },
    ],
    liveUrl: "https://pirate-battle-pi.vercel.app/",
    repositoryUrl: "https://github.com/leonardodariva/pirate-battle",
    visual: "pirate",
    coverImage:
      "https://raw.githubusercontent.com/leonardodariva/pirate-battle/main/assets/sample.png",
    gallery: [
      "https://raw.githubusercontent.com/leonardodariva/pirate-battle/main/assets/sample_menu.png",
      "https://raw.githubusercontent.com/leonardodariva/pirate-battle/main/assets/sample.png",
      "https://raw.githubusercontent.com/leonardodariva/pirate-battle/main/assets/sample_ranking.png",
      "https://raw.githubusercontent.com/leonardodariva/pirate-battle/main/assets/sample_result.png",
    ],
    featured: true,
  },
  {
    slug: "no-ritmo",
    title: "No Ritmo",
    eyebrow: "Produto real · Site institucional",
    year: "2026",
    summary:
      "Experiência digital para uma academia de dança, planejada para organizar serviços, modalidades, horários e conteúdo em uma presença institucional clara e acolhedora.",
    objective:
      "Estruturar uma grande quantidade de conteúdo sem perder ritmo, descoberta ou facilidade de manutenção em diferentes formatos de tela.",
    contribution:
      "Atuei na arquitetura da informação, design responsivo, sistema visual e implementação front-end com conteúdo desacoplado dos componentes.",
    challenge:
      "Criar uma base editorial extensível para páginas de aulas, projetos, formação, galeria e contato, mantendo consistência visual e técnica.",
    stack: ["React", "TypeScript", "Next.js", "CSS", "SEO", "Conteúdo estruturado"],
    features: [
      "Arquitetura de conteúdo reutilizável",
      "Navegação responsiva",
      "Páginas orientadas a SEO",
      "Galeria e diretório de projetos",
      "Experiência mobile-first",
      "Componentes editoriais compartilhados",
    ],
    repositoryUrl:
      "https://github.com/leonardodariva/no-ritmo-academia-de-danca",
    visual: "dance",
    coverImage:
      "https://raw.githubusercontent.com/leonardodariva/no-ritmo-academia-de-danca/main/public/images/demo/danca-hero-noritmo.png",
    gallery: [
      "https://raw.githubusercontent.com/leonardodariva/no-ritmo-academia-de-danca/main/public/images/demo/aula-em-grupo-noritmo.png",
      "https://raw.githubusercontent.com/leonardodariva/no-ritmo-academia-de-danca/main/public/images/demo/movimento-detalhe-noritmo.png",
    ],
    featured: false,
  },
];

export const technologyGroups = [
  {
    title: "Interface",
    description: "Da semântica ao sistema de componentes.",
    items: ["HTML5", "CSS3", "JavaScript", "TypeScript", "React", "Next.js", "Tailwind CSS"],
  },
  {
    title: "Engenharia",
    description: "Ferramentas para entregar com confiança.",
    items: ["Git", "GitHub", "Node.js", "Vite", "REST APIs", "Axios", "TanStack Query", "TanStack Router"],
  },
  {
    title: "Qualidade",
    description: "Comportamento verificado, não presumido.",
    items: ["Vitest", "Playwright", "TypeScript strict", "ESLint", "Acessibilidade", "Performance"],
  },
  {
    title: "Produto",
    description: "Um diferencial que aproxima código e pessoas.",
    items: ["Figma", "UI/UX", "Design Systems", "Prototipação", "UX Research", "PixiJS", "Socket.IO"],
  },
];

export const experience = [
  {
    company: "Futuro Corp",
    role: "UI/UX & Product Designer",
    period: "Atual",
    description:
      "Participação na definição e evolução de produtos digitais, conectando fluxos, componentes, experiência e validação com stakeholders.",
  },
  {
    company: "Glass Aplicativos e Softwares",
    role: "Desenvolvedor Web · UI/UX · Product Designer",
    period: "Experiência anterior",
    description:
      "Desenvolvimento de interfaces web, dashboards e páginas responsivas com HTML, CSS e JavaScript, além de arquitetura de informação, protótipos e contato com clientes.",
  },
];
